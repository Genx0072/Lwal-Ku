import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Pricing } from './components/Pricing';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';
import { Dashboard } from './components/Dashboard';

function App() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userPlan, setUserPlan] = useState<'free' | 'pro'>('free');

  const handleLogin = (plan: 'free' | 'pro' = 'free') => {
    setIsLoggedIn(true);
    setUserPlan(plan);
    setIsAuthModalOpen(false);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserPlan('free');
  };

  if (isLoggedIn) {
    return <Dashboard userPlan={userPlan} onLogout={handleLogout} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Header onOpenAuth={() => setIsAuthModalOpen(true)} />
      <Hero onGetStarted={() => setIsAuthModalOpen(true)} />
      <Features />
      <Pricing onSelectPlan={() => setIsAuthModalOpen(true)} />
      <Footer />
      
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
      />
    </div>
  );
}

export default App;