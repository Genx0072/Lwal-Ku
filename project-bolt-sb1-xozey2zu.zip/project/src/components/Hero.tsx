import React from 'react';
import { ArrowRight, Sparkles, Globe, Brain } from 'lucide-react';

interface HeroProps {
  onGetStarted: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onGetStarted }) => {
  return (
    <section className="pt-32 pb-20 px-4">
      <div className="container mx-auto text-center">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <Sparkles className="h-6 w-6 text-purple-400" />
            <span className="text-purple-400 font-semibold">AI-Powered Content Intelligence</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
            Summarize, Translate,
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
              {' '}Understand
            </span>
          </h1>
          
          <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
            Transform any content into clear summaries and translate them into any language. 
            Get the gist of what matters most with our advanced AI technology.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4 mb-12">
            <button
              onClick={onGetStarted}
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-4 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-200 transform hover:scale-105 flex items-center space-x-2"
            >
              <span>Start Free Trial</span>
              <ArrowRight className="h-5 w-5" />
            </button>
            <button className="border border-white/30 text-white px-8 py-4 rounded-lg font-semibold hover:bg-white/10 transition-all duration-200">
              Watch Demo
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Brain className="h-8 w-8 text-purple-400 mb-4 mx-auto" />
              <h3 className="text-white font-semibold mb-2">Smart Summarization</h3>
              <p className="text-white/70 text-sm">Extract key insights from any content with AI precision</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Globe className="h-8 w-8 text-purple-400 mb-4 mx-auto" />
              <h3 className="text-white font-semibold mb-2">Multi-Language Support</h3>
              <p className="text-white/70 text-sm">Translate summaries into 100+ languages instantly</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Sparkles className="h-8 w-8 text-purple-400 mb-4 mx-auto" />
              <h3 className="text-white font-semibold mb-2">Enhanced Context</h3>
              <p className="text-white/70 text-sm">Get additional relevant information and insights</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};