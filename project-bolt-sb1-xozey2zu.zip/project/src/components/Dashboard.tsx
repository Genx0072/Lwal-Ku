import React, { useState } from 'react';
import { FileText, Languages, Upload, Settings, LogOut, Crown, Sparkles, Copy, Download, Brain, BookOpen, TrendingUp } from 'lucide-react';

interface DashboardProps {
  userPlan: 'free' | 'pro';
  onLogout: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ userPlan, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'summarize' | 'translate' | 'history'>('summarize');
  const [inputText, setInputText] = useState('');
  const [summary, setSummary] = useState('');
  const [translation, setTranslation] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('my');
  const [isProcessing, setIsProcessing] = useState(false);
  const [summaryType, setSummaryType] = useState<'comprehensive' | 'detailed' | 'analytical'>('comprehensive');

  const languages = [
    { code: 'my', name: 'Burmese (Myanmar)' },
    { code: 'es', name: 'Spanish' },
    { code: 'fr', name: 'French' },
    { code: 'de', name: 'German' },
    { code: 'ja', name: 'Japanese' },
    { code: 'ko', name: 'Korean' },
    { code: 'zh', name: 'Chinese' },
    { code: 'ar', name: 'Arabic' },
    { code: 'ru', name: 'Russian' },
    { code: 'pt', name: 'Portuguese' },
    { code: 'it', name: 'Italian' },
    { code: 'th', name: 'Thai' },
    { code: 'vi', name: 'Vietnamese' },
    { code: 'hi', name: 'Hindi' },
    { code: 'bn', name: 'Bengali' }
  ];

  const summaryTypes = [
    {
      type: 'comprehensive' as const,
      title: 'Comprehensive Summary',
      description: 'Detailed overview with context and background',
      icon: BookOpen
    },
    {
      type: 'detailed' as const,
      title: 'Detailed Analysis',
      description: 'In-depth breakdown with explanations',
      icon: Brain
    },
    {
      type: 'analytical' as const,
      title: 'Analytical Insights',
      description: 'Critical analysis with implications and trends',
      icon: TrendingUp
    }
  ];

  const generateComprehensiveSummary = (text: string, type: string) => {
    const wordCount = text.split(' ').length;
    const readingTime = Math.ceil(wordCount / 200);
    const mainTopic = text.split(' ').slice(0, 5).join(' ');
    
    switch (type) {
      case 'comprehensive':
        return `📋 COMPREHENSIVE SUMMARY

🎯 MAIN TOPIC: ${mainTopic}...
📊 Document Stats: ${wordCount} words • ${readingTime} min read

📖 EXECUTIVE OVERVIEW:
This content provides a thorough examination of the subject matter, presenting multiple perspectives and comprehensive coverage. The material demonstrates significant depth and offers valuable insights for understanding the broader context.

🔍 KEY FINDINGS & INSIGHTS:
• Primary Focus: The content centers around core concepts that are essential for understanding the subject
• Supporting Evidence: Multiple data points and examples reinforce the main arguments
• Contextual Background: Historical and contemporary factors that influence the topic
• Practical Applications: Real-world implications and actionable takeaways
• Future Considerations: Potential developments and emerging trends

💡 DETAILED BREAKDOWN:
1. Introduction & Context Setting
   - Background information establishing the foundation
   - Scope and limitations of the discussion
   - Relevance to current situations and trends

2. Core Content Analysis
   - Main arguments and supporting evidence
   - Methodologies and approaches discussed
   - Critical evaluation of presented information

3. Implications & Applications
   - Practical uses and implementations
   - Potential challenges and solutions
   - Strategic considerations for stakeholders

🎯 ACTIONABLE INSIGHTS:
• Immediate Actions: Steps that can be taken right away
• Medium-term Planning: Considerations for ongoing development
• Long-term Strategy: Vision and future-oriented thinking

${userPlan === 'pro' ? `
🚀 ENHANCED PRO ANALYSIS:
• Cross-Reference Data: Related topics and connections identified
• Industry Benchmarks: Comparison with standard practices
• Risk Assessment: Potential challenges and mitigation strategies
• Opportunity Mapping: Areas for growth and development
• Expert Recommendations: Best practices and proven approaches
` : ''}

📈 CONCLUSION:
The content provides valuable information that can inform decision-making and strategic planning. The comprehensive nature of the material makes it suitable for both immediate reference and long-term strategic consideration.`;

      case 'detailed':
        return `🔬 DETAILED ANALYSIS REPORT

📋 DOCUMENT PROFILE:
• Content Length: ${wordCount} words
• Estimated Reading Time: ${readingTime} minutes
• Complexity Level: ${wordCount > 500 ? 'Advanced' : wordCount > 200 ? 'Intermediate' : 'Basic'}
• Primary Subject: ${mainTopic}...

🎯 STRUCTURED BREAKDOWN:

I. FOUNDATIONAL ELEMENTS
   A. Core Concepts Identified
      - Primary themes and recurring topics
      - Fundamental principles underlying the content
      - Essential terminology and definitions
   
   B. Contextual Framework
      - Historical background and development
      - Current market/industry conditions
      - Regulatory and environmental factors

II. CONTENT DEEP DIVE
   A. Main Arguments & Propositions
      - Central thesis and supporting claims
      - Evidence types: statistical, anecdotal, expert opinion
      - Logical flow and argument structure
   
   B. Supporting Information
      - Data sources and credibility assessment
      - Case studies and examples provided
      - Comparative analysis with alternatives

III. CRITICAL EVALUATION
   A. Strengths & Advantages
      - Well-supported arguments
      - Comprehensive coverage areas
      - Practical applicability
   
   B. Limitations & Considerations
      - Potential gaps in coverage
      - Assumptions and prerequisites
      - Areas requiring additional research

IV. PRACTICAL APPLICATIONS
   A. Implementation Strategies
      - Step-by-step approaches
      - Resource requirements
      - Timeline considerations
   
   B. Success Metrics
      - Key performance indicators
      - Measurement methodologies
      - Benchmarking standards

${userPlan === 'pro' ? `
V. ADVANCED INSIGHTS (PRO)
   A. Predictive Analysis
      - Trend forecasting based on content
      - Scenario planning considerations
      - Risk probability assessments
   
   B. Strategic Recommendations
      - Short-term tactical moves
      - Long-term strategic positioning
      - Competitive advantage opportunities
` : ''}

📊 SUMMARY METRICS:
• Information Density: High
• Actionability Score: ${Math.floor(Math.random() * 30) + 70}%
• Relevance Rating: ${Math.floor(Math.random() * 20) + 80}%
• Implementation Complexity: ${wordCount > 400 ? 'High' : 'Medium'}`;

      case 'analytical':
        return `📊 ANALYTICAL INSIGHTS & STRATEGIC OVERVIEW

🎯 EXECUTIVE INTELLIGENCE BRIEF
Subject Matter: ${mainTopic}...
Analysis Depth: ${wordCount} words analyzed
Strategic Value: High-impact insights for decision makers

🔍 MULTI-DIMENSIONAL ANALYSIS:

📈 TREND ANALYSIS & MARKET DYNAMICS
• Current State Assessment
  - Market positioning and competitive landscape
  - Performance indicators and benchmarks
  - Stakeholder sentiment and engagement levels

• Emerging Patterns
  - Growth trajectories and momentum indicators
  - Disruption signals and innovation markers
  - Adoption rates and market penetration

• Future Projections
  - Short-term outlook (3-6 months)
  - Medium-term trends (6-18 months)
  - Long-term strategic implications (2+ years)

🧠 STRATEGIC INTELLIGENCE
• Competitive Advantages Identified
  - Unique value propositions
  - Differentiation opportunities
  - Market positioning strengths

• Risk & Opportunity Matrix
  - High-impact, high-probability scenarios
  - Emerging threats and mitigation strategies
  - Untapped opportunities and market gaps

• Stakeholder Impact Analysis
  - Primary beneficiaries and affected parties
  - Influence networks and decision makers
  - Communication and engagement strategies

💡 ACTIONABLE INTELLIGENCE
• Immediate Priority Actions (0-30 days)
  - Quick wins and low-hanging fruit
  - Critical path dependencies
  - Resource allocation priorities

• Strategic Initiatives (30-90 days)
  - Medium-term project planning
  - Capability building requirements
  - Partnership and collaboration opportunities

• Transformational Moves (90+ days)
  - Long-term vision alignment
  - Innovation and R&D investments
  - Market expansion strategies

${userPlan === 'pro' ? `
🚀 PREMIUM STRATEGIC INSIGHTS:

📊 ADVANCED ANALYTICS
• Predictive Modeling Results
  - Success probability assessments
  - ROI projections and sensitivity analysis
  - Scenario planning with multiple variables

• Competitive Intelligence
  - Benchmarking against industry leaders
  - Best practice identification
  - Competitive response strategies

• Innovation Opportunities
  - Technology adoption potential
  - Process optimization areas
  - New market creation possibilities

🎯 EXECUTIVE RECOMMENDATIONS
• Board-Level Considerations
  - Strategic alignment with corporate vision
  - Resource allocation recommendations
  - Risk tolerance and appetite assessment

• Operational Excellence
  - Process improvement opportunities
  - Technology integration strategies
  - Performance optimization tactics
` : ''}

🎯 KEY PERFORMANCE INDICATORS
• Strategic Alignment Score: ${Math.floor(Math.random() * 15) + 85}%
• Implementation Readiness: ${Math.floor(Math.random() * 20) + 75}%
• Market Opportunity Size: ${wordCount > 300 ? 'Large' : 'Medium'}
• Competitive Advantage Potential: ${Math.floor(Math.random() * 25) + 70}%

📋 CONCLUSION & NEXT STEPS
This analysis reveals significant strategic value with multiple pathways for implementation. The comprehensive nature of the insights provides a solid foundation for informed decision-making and strategic planning across multiple time horizons.`;

      default:
        return summary;
    }
  };

  const handleSummarize = async () => {
    if (!inputText.trim()) return;
    
    setIsProcessing(true);
    // Simulate API call with longer processing time for comprehensive analysis
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const comprehensiveSummary = generateComprehensiveSummary(inputText, summaryType);
    setSummary(comprehensiveSummary);
    setIsProcessing(false);
  };

  const handleTranslate = async () => {
    if (!summary) return;
    
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const selectedLang = languages.find(lang => lang.code === selectedLanguage);
    setTranslation(`[Translated to ${selectedLang?.name}]\n\n${summary}`);
    setIsProcessing(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-purple-400" />
              <span className="text-2xl font-bold text-white">Lwal Kuu</span>
              {userPlan === 'pro' && (
                <div className="flex items-center space-x-1 bg-gradient-to-r from-purple-500 to-pink-500 px-3 py-1 rounded-full">
                  <Crown className="h-4 w-4 text-white" />
                  <span className="text-white text-sm font-semibold">Pro</span>
                </div>
              )}
            </div>
            
            <div className="flex items-center space-x-4">
              <button className="text-white/80 hover:text-white transition-colors">
                <Settings className="h-6 w-6" />
              </button>
              <button
                onClick={onLogout}
                className="text-white/80 hover:text-white transition-colors"
              >
                <LogOut className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <h2 className="text-xl font-bold text-white mb-6">Tools</h2>
              
              <nav className="space-y-2">
                <button
                  onClick={() => setActiveTab('summarize')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                    activeTab === 'summarize'
                      ? 'bg-purple-500 text-white'
                      : 'text-white/80 hover:bg-white/10'
                  }`}
                >
                  <Sparkles className="h-5 w-5" />
                  <span>Comprehensive Analysis</span>
                </button>
                
                <button
                  onClick={() => setActiveTab('translate')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                    activeTab === 'translate'
                      ? 'bg-purple-500 text-white'
                      : 'text-white/80 hover:bg-white/10'
                  }`}
                >
                  <Languages className="h-5 w-5" />
                  <span>Translate</span>
                </button>
                
                <button
                  onClick={() => setActiveTab('history')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                    activeTab === 'history'
                      ? 'bg-purple-500 text-white'
                      : 'text-white/80 hover:bg-white/10'
                  }`}
                >
                  <FileText className="h-5 w-5" />
                  <span>History</span>
                </button>
              </nav>
              
              {userPlan === 'free' && (
                <div className="mt-6 bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 rounded-lg p-4">
                  <h3 className="text-white font-semibold mb-2">Upgrade to Pro</h3>
                  <p className="text-white/80 text-sm mb-3">
                    Get unlimited comprehensive analysis, advanced insights, and strategic recommendations!
                  </p>
                  <button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-2 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition-all">
                    Upgrade Now
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {activeTab === 'summarize' && (
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <h2 className="text-2xl font-bold text-white mb-6">Comprehensive Content Analysis</h2>
                
                <div className="space-y-6">
                  {/* Summary Type Selection */}
                  <div>
                    <label className="block text-white font-semibold mb-3">
                      Analysis Type:
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {summaryTypes.map((type) => (
                        <button
                          key={type.type}
                          onClick={() => setSummaryType(type.type)}
                          className={`p-4 rounded-lg border transition-all ${
                            summaryType === type.type
                              ? 'bg-purple-500/30 border-purple-400 text-white'
                              : 'bg-white/5 border-white/20 text-white/80 hover:bg-white/10'
                          }`}
                        >
                          <type.icon className="h-6 w-6 mx-auto mb-2" />
                          <div className="text-sm font-semibold">{type.title}</div>
                          <div className="text-xs opacity-80 mt-1">{type.description}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">
                      Enter your content for comprehensive analysis:
                    </label>
                    <textarea
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      placeholder="Paste your article, research paper, business document, or any content here for detailed analysis with comprehensive insights, context, and actionable recommendations..."
                      className="w-full h-48 bg-white/10 border border-white/20 rounded-lg p-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                    />
                    <div className="text-white/60 text-sm mt-2">
                      {inputText.length} characters • {Math.ceil(inputText.split(' ').length / 200)} min read
                    </div>
                  </div>
                  
                  <div className="flex space-x-4">
                    <button
                      onClick={handleSummarize}
                      disabled={!inputText.trim() || isProcessing}
                      className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                    >
                      {isProcessing ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                          <span>Analyzing...</span>
                        </>
                      ) : (
                        <>
                          <Brain className="h-5 w-5" />
                          <span>Generate Comprehensive Analysis</span>
                        </>
                      )}
                    </button>
                    
                    <button className="bg-white/10 border border-white/20 text-white px-4 py-3 rounded-lg hover:bg-white/20 transition-all">
                      <Upload className="h-5 w-5" />
                    </button>
                  </div>
                  
                  {summary && (
                    <div className="bg-white/5 border border-white/10 rounded-lg p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-white font-semibold text-lg">Comprehensive Analysis Results:</h3>
                        <div className="flex space-x-2">
                          <button className="text-white/60 hover:text-white transition-colors p-2 rounded-lg hover:bg-white/10">
                            <Copy className="h-4 w-4" />
                          </button>
                          <button className="text-white/60 hover:text-white transition-colors p-2 rounded-lg hover:bg-white/10">
                            <Download className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                      <div 
                        className="text-white/90 whitespace-pre-wrap text-sm leading-relaxed max-h-96 overflow-y-auto bg-black/20 p-4 rounded-lg"
                        style={{ fontFamily: '"Times New Roman", Times, serif' }}
                      >
                        {summary}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'translate' && (
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <h2 className="text-2xl font-bold text-white mb-6">Translation</h2>
                
                <div className="space-y-6">
                  <div>
                    <label className="block text-white font-semibold mb-2">
                      Select target language:
                    </label>
                    <select
                      value={selectedLanguage}
                      onChange={(e) => setSelectedLanguage(e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      {languages.map((lang) => (
                        <option key={lang.code} value={lang.code} className="bg-slate-800">
                          {lang.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <button
                    onClick={handleTranslate}
                    disabled={!summary || isProcessing}
                    className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white py-3 rounded-lg font-semibold hover:from-green-600 hover:to-blue-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                  >
                    {isProcessing ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        <span>Translating...</span>
                      </>
                    ) : (
                      <>
                        <Languages className="h-5 w-5" />
                        <span>Translate Comprehensive Analysis</span>
                      </>
                    )}
                  </button>
                  
                  {!summary && (
                    <p className="text-white/60 text-center">
                      Please create a comprehensive analysis first to translate
                    </p>
                  )}
                  
                  {translation && (
                    <div className="bg-white/5 border border-white/10 rounded-lg p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-white font-semibold text-lg">Translation:</h3>
                        <div className="flex space-x-2">
                          <button className="text-white/60 hover:text-white transition-colors p-2 rounded-lg hover:bg-white/10">
                            <Copy className="h-4 w-4" />
                          </button>
                          <button className="text-white/60 hover:text-white transition-colors p-2 rounded-lg hover:bg-white/10">
                            <Download className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                      <div 
                        className="text-white/90 whitespace-pre-wrap text-sm leading-relaxed max-h-96 overflow-y-auto bg-black/20 p-4 rounded-lg"
                        style={{ fontFamily: '"Times New Roman", Times, serif' }}
                      >
                        {translation}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'history' && (
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <h2 className="text-2xl font-bold text-white mb-6">Analysis History</h2>
                
                <div className="text-center text-white/60 py-12">
                  <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No comprehensive analyses yet. Create your first analysis to see history here.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};