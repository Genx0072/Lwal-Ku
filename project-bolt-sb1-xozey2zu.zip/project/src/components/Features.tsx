import React from 'react';
import { FileText, Languages, Zap, Shield, Clock, Users } from 'lucide-react';

export const Features: React.FC = () => {
  const features = [
    {
      icon: FileText,
      title: 'Content Summarization',
      description: 'Transform lengthy articles, documents, and videos into concise, actionable summaries.',
      color: 'from-blue-500 to-purple-500'
    },
    {
      icon: Languages,
      title: 'Multi-Language Translation',
      description: 'Translate summaries into 100+ languages with context-aware accuracy.',
      color: 'from-green-500 to-blue-500'
    },
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Get summaries and translations in seconds, not minutes.',
      color: 'from-yellow-500 to-red-500'
    },
    {
      icon: Shield,
      title: 'Secure & Private',
      description: 'Your content is processed securely with end-to-end encryption.',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Clock,
      title: 'Save Time',
      description: 'Reduce reading time by up to 80% while retaining key information.',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      icon: Users,
      title: 'Team Collaboration',
      description: 'Share summaries with your team and collaborate on insights.',
      color: 'from-pink-500 to-red-500'
    }
  ];

  return (
    <section id="features" className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Powerful Features
          </h2>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Everything you need to understand and process content efficiently
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105"
            >
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${feature.color} flex items-center justify-center mb-6`}>
                <feature.icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-4">{feature.title}</h3>
              <p className="text-white/70">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};