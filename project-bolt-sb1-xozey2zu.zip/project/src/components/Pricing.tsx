import React from 'react';
import { Check, Star, Crown } from 'lucide-react';

interface PricingProps {
  onSelectPlan: () => void;
}

export const Pricing: React.FC<PricingProps> = ({ onSelectPlan }) => {
  const plans = [
    {
      name: 'Free',
      price: '0',
      currency: 'USD',
      description: 'Perfect for getting started',
      features: [
        '5 summaries per day',
        'Basic translation',
        'Text content only',
        'Standard processing speed',
        'Email support'
      ],
      buttonText: 'Get Started Free',
      popular: false,
      icon: Star
    },
    {
      name: 'Pro',
      price: '9.99',
      currency: 'USD',
      description: 'For power users and professionals',
      features: [
        'Unlimited summaries',
        'Advanced translation (100+ languages)',
        'Video, audio, and document support',
        'Priority processing',
        'Advanced context enhancement',
        'Team collaboration',
        'Priority support',
        'Export to multiple formats'
      ],
      buttonText: 'Upgrade to Pro',
      popular: true,
      icon: Crown
    }
  ];

  return (
    <section id="pricing" className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Choose the plan that fits your needs. Start free, upgrade when ready.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-2xl p-8 border-2 transition-all duration-300 hover:scale-105 ${
                plan.popular
                  ? 'border-purple-500 bg-gradient-to-b from-purple-900/50 to-pink-900/50'
                  : 'border-white/20 bg-white/10 backdrop-blur-sm'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="text-center mb-8">
                <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${
                  plan.popular ? 'from-purple-500 to-pink-500' : 'from-gray-600 to-gray-700'
                } flex items-center justify-center mb-4 mx-auto`}>
                  <plan.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                <p className="text-white/70 mb-4">{plan.description}</p>
                <div className="text-white">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="text-white/70">/month</span>
                </div>
              </div>
              
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-400 flex-shrink-0" />
                    <span className="text-white/80">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button
                onClick={onSelectPlan}
                className={`w-full py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 ${
                  plan.popular
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600'
                    : 'bg-white/10 text-white border border-white/30 hover:bg-white/20'
                }`}
              >
                {plan.buttonText}
              </button>
              
              {plan.name === 'Pro' && (
                <div className="mt-4 text-center">
                  <p className="text-white/60 text-sm">Payment via KPay, WaveMoney, or Card</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};